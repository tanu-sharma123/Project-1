jQuery(document).ready(function($) {
  $('#submit-btn').click(function() {
    var name = $('#name').val();
    var email = $('#email').val();
    var message = $('#message').val();

    $.ajax({
      url: ajax_object.ajax_url,
      method: 'POST',
      data: {
        action: 'submit_contact_form',
        name: name,
        email: email,
        message: message
      },
      beforeSend: function() {
        $('#response-msg').text('Sending...');
      },
      success: function(response) {
        $('#response-msg').html('<strong>' + response.data + '</strong>');
      },
      error: function() {
        $('#response-msg').text('There was an error.');
      }
    });
  });
});
