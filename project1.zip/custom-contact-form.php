<?php
/*
Plugin Name: Custom Contact Form (AJAX)
Description: A simple contact form using AJAX, jQuery, and PHP.
Version: 1.0
Author: ChatGPT
*/

add_action('wp_enqueue_scripts', function() {
  wp_enqueue_script('jquery');
  wp_enqueue_script('custom-ajax', plugin_dir_url(__FILE__) . 'js/custom.js', ['jquery'], null, true);
  wp_localize_script('custom-ajax', 'ajax_object', [
    'ajax_url' => admin_url('admin-ajax.php')
  ]);
  wp_enqueue_style('custom-form-style', plugin_dir_url(__FILE__) . 'css/style.css');
});

add_action('wp_ajax_submit_contact_form', 'handle_contact_form');
add_action('wp_ajax_nopriv_submit_contact_form', 'handle_contact_form');

function handle_contact_form() {
  $name = sanitize_text_field($_POST['name']);
  $email = sanitize_email($_POST['email']);
  $message = sanitize_textarea_field($_POST['message']);

  if (empty($name) || empty($email) || empty($message)) {
    wp_send_json_error('All fields are required.');
  }

  wp_send_json_success('Thank you for contacting us!');
}
?>
